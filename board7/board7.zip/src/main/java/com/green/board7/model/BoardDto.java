package com.green.board7.model;
//페이징 받은거 저장
public class BoardDto extends BoardEntity{
}