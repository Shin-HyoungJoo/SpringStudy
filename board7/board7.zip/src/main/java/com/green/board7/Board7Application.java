package com.green.board7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Board7Application {

    public static void main(String[] args) {
        SpringApplication.run(Board7Application.class, args);
    }

}
